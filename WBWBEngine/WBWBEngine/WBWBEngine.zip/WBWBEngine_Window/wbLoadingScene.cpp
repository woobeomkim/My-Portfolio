#include "wbLoadingScene.h"

namespace wb
{
	LoadingScene::LoadingScene()
	{
	}
	LoadingScene::~LoadingScene()
	{
	}
	void LoadingScene::Initialize()
	{
	}
	void LoadingScene::Update()
	{
	}
	void LoadingScene::LateUpdate()
	{
	}
	void LoadingScene::Render(HDC hdc)
	{
	}
	void LoadingScene::OnEnter()
	{
	}
	void LoadingScene::OnExit()
	{
	}
}