#include "BattleBase.h"

namespace wb
{
	BattleBase::BattleBase()
		: mName{}
		, mLearnalbeMove{}
		, mStat{}
	{

	}

	BattleBase::~BattleBase()
	{

	}
}