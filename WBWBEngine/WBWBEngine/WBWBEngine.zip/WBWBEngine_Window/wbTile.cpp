#include "wbTile.h"

namespace wb
{
	void Tile::Initialize()
	{
	}
	void Tile::Update()
	{
	}
	void Tile::LateUpdate()
	{
	}
	void Tile::Render(HDC hdc)
	{
	}
}