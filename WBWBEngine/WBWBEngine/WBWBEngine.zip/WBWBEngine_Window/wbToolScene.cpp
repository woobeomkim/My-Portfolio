#include "wbToolScene.h"
#include "wbObject.h"
#include "wbGameObject.h"
#include "wbTransform.h"
#include "wbCamera.h"
#include "wbRenderer.h"
#include "wbTile.h"
#include "wbTilemapRenderer.h"
#include "wbResources.h"

namespace wb
{
	ToolScene::ToolScene()
	{
	}
	ToolScene::~ToolScene()
	{
	}
	void ToolScene::Initialize()
	{
		GameObject* camera = Instantiate<GameObject>(eLayerType::Particle, Vector2(344.0f, 442.0f));
		Camera* cameraComp = camera->AddComponent<Camera>();
		mainCamera = cameraComp;

		Tile* tile = Instantiate<Tile>(eLayerType::Tile);
		TilemapRenderer* tmr = tile->AddComponent<TilemapRenderer>();

		//tmr->SetTexture(Resources::Find(L"dd"));
		
		Scene::Initialize();
	}
	void ToolScene::Update()
	{
		Scene::Update();
	}
	void ToolScene::LateUpdate()
	{
		Scene::LateUpdate();
	}
	void ToolScene::Render(HDC hdc)
	{
		Scene::Render(hdc);

		for (int i = 0; i < 50; i++)
		{
			MoveToEx(hdc, (16 * 3) * i, 0, nullptr);
			LineTo(hdc, (16 * 3) * i, 1000);
		}

		for (int i = 0; i < 50; i++)
		{
			MoveToEx(hdc, 0, (16 * 3) * i, nullptr);
			LineTo(hdc, 1000, (16 * 3) * i);
		}
	}
	void ToolScene::OnEnter()
	{
		Scene::OnEnter();
	}
	void ToolScene::OnExit()
	{
		Scene::OnExit();
	}
}