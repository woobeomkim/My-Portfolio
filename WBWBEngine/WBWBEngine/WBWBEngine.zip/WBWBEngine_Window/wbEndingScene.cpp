#include "wbEndingScene.h"

namespace wb
{
	EndingScene::~EndingScene()
	{
	}
	void EndingScene::Initialize()
	{
	}
	void EndingScene::Update()
	{
	}
	void EndingScene::LateUpdate()
	{
	}
	void EndingScene::Render(HDC hdc)
	{
	}
	void EndingScene::OnEnter()
	{
	}
	void EndingScene::OnExit()
	{
	}
}