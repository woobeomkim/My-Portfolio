#pragma once
#include "wbCamera.h"

namespace wb
{
	extern Camera* mainCamera;
}

