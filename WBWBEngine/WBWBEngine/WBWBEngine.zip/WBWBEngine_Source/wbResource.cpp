#include "wbResource.h"

namespace wb
{
	Resource::Resource(eResourceType type) : mType(type)
	{
	}
	Resource::~Resource()
	{
	}
}