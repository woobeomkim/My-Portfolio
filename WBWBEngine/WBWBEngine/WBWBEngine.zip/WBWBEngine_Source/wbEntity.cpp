#include "wbEntity.h"

namespace wb
{
	Entity::Entity()
	{
	}
	Entity::~Entity()
	{
	}
}