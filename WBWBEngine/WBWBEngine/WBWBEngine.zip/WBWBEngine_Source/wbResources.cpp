#include "wbResources.h"

namespace wb
{
	std::map<std::wstring, Resource*> Resources::mResources = {};
}