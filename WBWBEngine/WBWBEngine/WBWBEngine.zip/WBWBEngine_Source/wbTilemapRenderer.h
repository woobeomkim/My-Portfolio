#pragma once
#include "wbComponent.h"
#include "wbTexture.h"

namespace wb
{
    class TilemapRenderer : public Component
    {
	public:
		TilemapRenderer();
		~TilemapRenderer();
		virtual void Initialize() override;
		virtual void Update() override;
		virtual void LateUpdate() override;
		virtual void Render(HDC hdc) override;

		void SetTexture(Texture* texture) { mTexture = texture; }
		void SetSize(Vector2 size) { mSize = size; }

	private:
		Vector2 mTileSize;
		Texture* mTexture;
		Vector2 mSize;
		Vector2 mIndex;
    };
}
