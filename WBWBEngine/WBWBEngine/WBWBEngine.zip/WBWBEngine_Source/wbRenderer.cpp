#include "wbRenderer.h"

namespace wb
{
	Camera* mainCamera = nullptr;
}